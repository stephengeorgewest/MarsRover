#!/bin/sh
#
# MultiCam 6.4.0.391 Setup Script - EURESYS s.a.

MULTICAM_VERSION=6.4.0.391

INSTALL_DIR=/usr/local/euresys/multicam

MULTICAMSO=libMultiCam.so
MULTICAMSOVER=libMultiCam.so.$MULTICAM_VERSION
CLSEREMCSO=libclseremc.so
CLSEREMCSOVER=libclseremc.so.$MULTICAM_VERSION

REBOOT_NEEDED=n

echo "Installing MultiCam $MULTICAM_VERSION . . ."
echo

if [ `id -u` -ne 0 ]; then
    echo "Please install as root."
    exit 1
fi

if [ "`uname -m | grep "i[3-9]86"`" ]; then
    echo
else
    echo "A 64-bit OS has been detected."
    echo "MultiCam only works on a 32-bit OS."
    exit 1
fi

# Check if the system configuration will allow loading the drivers
if [ -e /etc/sysconfig/hardware/config ]; then 
    if [ ! "`grep LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=yes /etc/sysconfig/hardware/config`" ]; then
        echo "The system is not configured to automatically load the drivers."
        echo
        echo "Please replace the line LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=no in "
        echo "/etc/sysconfig/hardware/config by LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=yes."
        exit 1
    fi
fi

# Check existence of kernel sources
if [ ! -e /lib/modules/$(uname -r)/build/Makefile ]; then
    echo "/lib/modules/$(uname -r)/build/Makefile does not exist."
    echo "Please install kernel sources."
    exit 2
fi

rm -rf $INSTALL_DIR
mkdir -p $INSTALL_DIR
cp -r * $INSTALL_DIR

cd $INSTALL_DIR
rm -f install.sh

# MultiCam libs
echo "Copying MultiCam libraries . . ."
if [ -e drivers/$MULTICAMSO ]; then
    cp -f drivers/$MULTICAMSO /usr/lib/$MULTICAMSO
fi
mv -f drivers/$MULTICAMSOVER /usr/lib
if [ -e /usr/lib/$MULTICAMSO ]; then
    rm /usr/lib/$MULTICAMSO
fi
ln -s /usr/lib/$MULTICAMSOVER /usr/lib/$MULTICAMSO

mv -f drivers/$CLSEREMCSOVER /usr/lib
if [ -e /usr/lib/$CLSEREMCSO ]; then
    rm /usr/lib/$CLSEREMCSO
fi
ln -s /usr/lib/$CLSEREMCSOVER /usr/lib/$CLSEREMCSO

# config files
cp -f scripts/multicam /etc/modprobe.d/
cp -f scripts/multicam.conf /etc/

# MultiCam Studio
if [ -e bin/ ]; then
    cp -f bin/MultiCamStudio /usr/bin/
    /sbin/ldconfig -n $INSTALL_DIR/bin
fi

# MyCamFiles
mkdir -p cameras/MyCamFiles
chmod ugo+rw cameras/MyCamFiles

# Unpack documentation
if [ -e doc/ ]; then
    echo
    echo "Unpacking MultiCam documentation . . ."
    cd $INSTALL_DIR/doc
    tar -xzvf html.tar.gz
    rm html.tar.gz
fi

# Build kernel mode drivers
echo
echo "Installing MultiCam drivers . . ."
cd $INSTALL_DIR/drivers/linux/
cp ../precompiled/*.o .
./build.sh suse10

cd /lib/modules/$KERNEL_PATH/
sudo /sbin/depmod
cd

# Remove bttv driver
/sbin/rmmod bt878 2> /dev/null
/sbin/rmmod bttv 2> /dev/null

# Remove cx... driver
if [ "`/sbin/lsmod | grep cx88`" ]; then
    for cx_module in cx8800 cx88_blackbird cx88_dvb cx8802 cx88xx btcx_risc cx22702
      do
      /sbin/rmmod $cx_module 2> /dev/null
    done
    REBOOT_NEEDED=y
fi

# Insert MultiCam drivers
echo "Insert MultiCam drivers"
/sbin/rmmod UniMc 2> /dev/null
PICOLO="PicoloPro Alert Diligent"
GRABLINK="GlValue GlExpert GlAvenue GlClrScn GlCfa GlCfae"
DOMINO="Alpha Delta Iota"
DOMINOD3="Harmony Melody Symphony"

for module in $PICOLO $GRABLINK $DOMINO $DOMINOD3
  do
  echo $module
  /sbin/rmmod $module 2> /dev/null
  /sbin/modprobe $module 2> /dev/null
done

echo
echo "MultiCam was installed successfully, enjoy !"

if [ $REBOOT_NEEDED = y ]; then
    echo ""
    echo "To complete the installation procedure you should now restart your computer."
    echo ""
fi

exit 0
