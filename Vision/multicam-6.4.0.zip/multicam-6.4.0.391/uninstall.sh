MULTICAM_DIR=/usr/local/euresys/multicam/

KERNEL_PATH=`uname -r`
DRIVERS_DIR=/lib/modules/$KERNEL_PATH/kernel/drivers/char/

if [ `id -u` -ne 0 ]; then
    echo "Please run \"./uninstall\" as root."
    exit 0
fi

echo "This script will remove all MultiCam components"
echo "Do you want to continue ? [y / n] : "
read response
case $response in
    [yY]*) echo "Uninstall MultiCam..."
    ;;
    *) echo "Exit."
    exit 0;;
esac

# Unload drivers
PICOLO="PicoloPro Alert Diligent"
GRABLINK="GlValue GlExpert GlAvenue GlClrScn GlCfa GlCfae"
DOMINO="Alpha Delta Iota"
DOMINOD3="Harmony Melody Symphony"

for module in $PICOLO $GRABLINK $DOMINO $DOMINOD3
  do
  /sbin/rmmod $module 2> /dev/null
  rm -f $DRIVERS_DIR/$module.ko
done

# Remove all files
rm -f /usr/lib/libMultiCam.so*
rm -f /usr/lib/libclseremc.so*
rm -f /etc/multicam.conf
rm -f /etc/modprobe.d/multicam
if [ -e /usr/bin/MultiCamStudio ]; then
    rm -f /usr/bin/MultiCamStudio
fi
rm -rf $MULTICAM_DIR

echo "MultiCam was uninstalled successfully !"
