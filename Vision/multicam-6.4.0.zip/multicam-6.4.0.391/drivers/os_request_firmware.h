#ifndef OS_REQUEST_FIRMWARE_HEADER_FILE
#define OS_REQUEST_FIRMWARE_HEADER_FILE

#include "os_size_t.h"
#include "os_types.h"

/** OsFirmware structure contains the pointer
 *  to the buffer holding the \param image of the firmware
 *  and the \param size of this image.
 *  It also contains a pointer to an internal
 *  OS specific data.
 */
typedef struct {
    unsigned char *image;
    size_t size;
    const void *osSpecificValue;
} OsFirmware;

#ifdef __cplusplus
extern "C" 
{
#endif

/** RequestFirmware requests a firmware whose name is \param firmwareName
 *  from the Windows kernel or the Linux hotplug/udev subsystem.
 *  Upon success, the retrieved firmware is stored at \param firmwareImage.
 *  \param device must be set to a pointer to the DEVICE
 *  for which the firmware is to be loaded.
 *  RequestFirmware returns 0 on success and a negative
 *  value on error.
 */
int MC_API RequestFirmware(const char *firmwareName, OsFirmware *firmwareImage,
                    PDEVICE device);

void MC_API ReleaseFirmware(OsFirmware *firmwareImage);

#ifdef __cplusplus
}
#endif

#endif
