#ifndef OS_TYPES_HEADER_FILE
#define OS_TYPES_HEADER_FILE

#include "../os_size_t.h"

#define MC_API __attribute__((regparm(0)))


typedef unsigned long ULONG;
typedef unsigned long *PULONG;
typedef unsigned int DWORD;
typedef unsigned char UCHAR;
typedef unsigned char *PUCHAR;
typedef unsigned short USHORT;
typedef unsigned short *PUSHORT;

typedef unsigned int UINT32, UINT;
typedef unsigned int *PUINT32;
typedef unsigned short UINT16;
typedef unsigned short *PUINT16;
typedef unsigned char UINT8;
typedef unsigned char *PUINT8;
typedef signed int INT32;
typedef signed int *PINT32;
typedef signed short INT16;
typedef signed short *PINT16;
typedef signed char INT8;
typedef signed char *PINT8;
typedef char CHAR;
typedef char *PCHAR;
typedef const char *PCCHAR;
typedef float FLOAT32;
typedef float *PFLOAT32;
typedef double FLOAT64;
typedef double *PFLOAT64;

typedef long LONG;
typedef long *PLONG;
typedef short SHORT;
typedef short *PSHORT;

typedef long long INT64, *PINT64;
typedef long long LONGLONG;
typedef unsigned long long UINT64;
typedef unsigned long long ULONGLONG;
typedef unsigned short WCHAR;
typedef WCHAR *PWCHAR;
typedef WCHAR *LPWSTR, *PWSTR;

typedef long INT_PTR;
typedef unsigned long UINT_PTR;

// 64 bits constant
#define _64b(constant) (constant##LL)


//
// Boolean
//
typedef UCHAR BOOLEAN;
typedef BOOLEAN *PBOOLEAN;

#ifndef VOID
#define VOID void
#endif
typedef VOID *PVOID;
typedef PVOID PIRP;


typedef VOID DMA_OBJECT, *PDMA_OBJECT;
typedef VOID DEVICE;
typedef DEVICE *PDEVICE;

//
// Constants
//
#define FALSE   0
#define TRUE    1
#ifndef NULL
#define NULL    0
#endif

#define MC_MAX_BOARDS 8
#define MC_MAX_DEVICES 16
#define MC_MAX_RESOURCES 12

enum {
  RESOURCE_IO,
  RESOURCE_MEM,
  RESOURCE_IRQ,
  RESOURCE_DMA,
  RESOURCE_UNKNOWN
};

typedef int OS_INTERRUPT;

typedef INT32 MC_API (*READ_PROC_ROUTINE)(PCHAR buffer, PCHAR *start, PVOID off, INT32 count, PINT32 eof, PVOID data);
typedef BOOLEAN MC_API (*ISR_ROUTINE)(OS_INTERRUPT irq, PVOID ctx);
typedef VOID MC_API (*WORK_ROUTINE)(PVOID ctx);

typedef union
{
	struct
	{
		UINT32 LowPart;
		INT32 HighPart;
    };
    LONGLONG	QuadPart;
} PHYSICAL_ADDR;

typedef struct
{
	PHYSICAL_ADDR Base;
	UINT32 Length;
	UINT32 Offset;
	PVOID PageObject;
} _PAGE_ENTRY;

/*
 This has at least the same size as the biggest of the structures
 tq_struct and work_struct from Linux kernel 2.4 and 2.6.

    struct tq_struct {
        struct tq_struct *next;
        int sync;
        void (*routine)(void *);
        void *data;
    };

    struct work_struct {
        unsigned long pending;
        struct list_head entry;
        void (*func)(void *);
        void *data;
        void *wq_data;
        struct timer_list timer

    struct timer_list {
        struct list_head entry;
        unsigned long expires;
        unsigned long magic;
        void (*function)(unsigned long);
        unsigned long data;
        struct timer_base_s *base;
    };

    struct list_head {
        struct list_head *next, *prev;
    };

  13 longs for work_struct (6 + 7 for timer_list), 16 should do it.
*/
typedef struct {
    unsigned long linux_task_data[16];
} OS_TASK;

typedef int DRVSTATUS;

#endif
