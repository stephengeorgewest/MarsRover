/****************************************************************
* MultiCam LINUX DRIVER                                         *
* OS INTERFACE MODULE                                           *
* Copyright 2002-2007 Euresys                                   *
****************************************************************/

#include "mc_linux.h"
#include "../os_interface.h"

/* The following functions are used to read or write a PCI configuration
   register. Remark: the device pointer is passed as a PVOID and re-casted
   as a struct pci_dev pointer.
*/
INT32 MC_API mc_pci_read_config_byte(PDEVICE pcidev, UINT32 where, PUCHAR ptr)
{
    return pci_read_config_byte((struct pci_dev *)pcidev, (int)where, (u8 *)ptr);
}

INT32 MC_API mc_pci_write_config_byte(PDEVICE pcidev, UINT32 where, UCHAR val)
{
    return pci_write_config_byte((struct pci_dev *)pcidev, (int)where, (u8)val);
}

INT32 MC_API mc_pci_read_config_word(PDEVICE pcidev, UINT32 where, PUSHORT ptr)
{
    return pci_read_config_word((struct pci_dev *)pcidev, (int)where, (u16 *)ptr);
}

INT32 MC_API mc_pci_write_config_word(PDEVICE pcidev, UINT32 where, USHORT val)
{
    return pci_write_config_word((struct pci_dev *)pcidev, (int)where, (u16)val);
}

INT32 MC_API mc_pci_read_config_dword(PDEVICE pcidev, UINT32 where, PUINT32 ptr)
{
    return pci_read_config_dword((struct pci_dev *)pcidev, (int)where, (u32 *)ptr);
}

INT32 MC_API mc_pci_write_config_dword(PDEVICE pcidev, UINT32 where, UINT32 val)
{
    return pci_write_config_dword((struct pci_dev *)pcidev, (int)where, (u32)val);
}


// Fill memory with a constant byte
void *MC_API os_memset(void *s, INT32 c, UINT32 n)
{
    return memset(s, c, n);
}

// copy memory area
void *MC_API os_memcpy(void *dest, const void *src, UINT32 n)
{
    return memcpy(dest, src, n);
}

void *MC_API os_memmove(void *dest, const void *src, UINT32 n)
{
    return memmove(dest, src, n);
}

static void task_entry(unsigned long context)
{
    struct OS_DPC *dpc = (struct OS_DPC *)context;
    dpc->callback(dpc->context);
}

/** Create a barrier at this position in the code.
 **/
void MC_API OsMemoryBarrier()
{
    smp_mb();
}


/** Create a DPC.

    This function can be called only at the passive level.
    \param dpc pointer to a preallocated structure that will contain the dpc object
    \param callback callback that will be called when executing the deferred
    \param context  context that will be passed to the callback
**/
void MC_API OsCreateDpc(struct OS_DPC *dpc, void (*callback)(PVOID context), PVOID context)
{
    dpc->callback = (void MC_API (*)(PVOID))callback;
    dpc->context = context;
    tasklet_init((struct tasklet_struct*)dpc->native_dpc, task_entry, (ULONG)dpc);
}


/** Free a DPC.

    This function can be called only at the passive level. No DPC may be running anymore.
    \param dpc pointer to the DPC object that needs to be freeed.
**/
void MC_API OsDeleteDpc(struct OS_DPC *dpc)
{
}


/** Queue a call. The DPC will be run as soon as possible by the OS.

    This function can only be called when executing a deferred or an interrupt handler.
    \param dpc pointer to the DPC object.
**/
BOOLEAN MC_API OsQueueDpc(struct OS_DPC *dpc)
{
    tasklet_schedule((struct tasklet_struct *)dpc->native_dpc);
    return TRUE;
}


