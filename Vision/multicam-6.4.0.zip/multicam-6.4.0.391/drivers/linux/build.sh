# build kernel mode drivers

KERNEL_PATH=`uname -r`
DRIVERS_LIST="PicoloPro GlValue GlExpert GlAvenue GlCfa GlCfae GlClrScn Alert Diligent Melody Harmony Symphony Alpha Delta Iota"
platform=""

if [ "`uname -m | grep x86_64`" ]; 
then
    platform="-DEURESYS_64_BITS"
fi

DEST_DIR=/lib/modules/$KERNEL_PATH/kernel/drivers/char/
cp Makefile.suse10 Makefile
echo
for module in $DRIVERS_LIST
do
    echo Building $module
    make MODULE=$module PLATFORM=$platform
    cp -f $module.ko $DEST_DIR
    echo
done
