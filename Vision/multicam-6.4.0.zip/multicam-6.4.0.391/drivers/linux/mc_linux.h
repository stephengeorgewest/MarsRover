#ifndef _MC_LINUX_H_
#define _MC_LINUX_H_

#ifdef EURESYS_OSAL_UNITTEST
#include "UnitTests/linuxFakes.h"
#else
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <linux/types.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/proc_fs.h>
#include <linux/spinlock.h>
#include <linux/timex.h>
#include <linux/timer.h>
#include <linux/poll.h>

#include <linux/pagemap.h>
#include <linux/swap.h>

#include <asm/uaccess.h>
#include <asm/semaphore.h>
#endif

#endif
