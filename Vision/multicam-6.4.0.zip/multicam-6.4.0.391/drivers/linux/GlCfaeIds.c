#include "mc_linux.h"

const struct pci_device_id multicam_ids[] = {
	{PCI_DEVICE(0x1805,0x0308)},
	{PCI_DEVICE(0x1805,0x0309)},
	{0,0}
};

char *driver_name = "glcfae";

MODULE_DEVICE_TABLE(pci, multicam_ids);
