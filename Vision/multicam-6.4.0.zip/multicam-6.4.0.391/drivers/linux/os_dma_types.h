#ifndef OS_DMA_TYPES_HEADER
#define OS_DMA_TYPES_HEADER

#include "os_types.h"
struct SG_LIST;
struct MEMORY_DESCRIPTION;

#endif

