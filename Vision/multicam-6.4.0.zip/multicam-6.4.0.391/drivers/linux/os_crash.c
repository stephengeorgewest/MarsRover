#include "../os_crash.h"
#include "mc_linux.h"
#include "../mc_interface.h"

void MC_API OsCrash(unsigned short errorCode)
{
    mc_printk("Oops: 0x%x\n", errorCode);
    BUG();
}

