/****************************************************************
* MultiCam LINUX DRIVER                                         *
* OS INTERFACE MODULE                                           *
* Copyright 2002-2007 Euresys                                   *
****************************************************************/

#include "mc_linux.h"
#include "../mc_interface.h"

#if (MC_MAX_RESOURCES < DEVICE_COUNT_RESOURCE)
     #error "Not enough resources"
#endif

#define PAGE_OFFSET_MASK (PAGE_SIZE-1)

int device_open (struct inode *, struct file *);
int device_release (struct inode *, struct file *);
ssize_t device_read (struct file *, char *, size_t , loff_t *);
ssize_t device_write (struct file *, const char *, size_t , loff_t *);
int device_ioctl (struct inode *, struct file *, unsigned int, unsigned long);
long device_compat_ioctl(struct file *, unsigned int, unsigned long);
static int add_device(struct pci_dev *dev);
unsigned int device_poll(struct file *, struct poll_table_struct *);

static int dev_number = 0;

extern const struct pci_device_id multicam_ids[];

// Driver entry points 
struct file_operations fops = {
    read: device_read,
    write: device_write,
    ioctl: device_ioctl,
    #ifdef HAVE_COMPAT_IOCTL
    compat_ioctl: device_compat_ioctl,
    #endif
    open: device_open,
    release: device_release,
    poll: device_poll
};

static int probe(struct pci_dev *dev, const struct pci_device_id *id) 
{
    return add_device(dev);
}

static void remove(struct pci_dev *dev) 
{
    // TODO ?
}

extern char *driver_name;

static struct pci_driver multicam_driver = {
    .id_table = multicam_ids,
    .probe = probe,
    .remove = remove,
};

INT32 MC_API mc_register_driver(void) {
    int ret;
    multicam_driver.name = driver_name;
    ret = pci_register_driver(&multicam_driver);
    if (ret < 0)
        return ret;

    if (dev_number == 0) {
        pci_unregister_driver(&multicam_driver);
        return -ENODEV;
    }
    return 0;
}

INT32 MC_API mc_unregister_driver(void) {
    pci_unregister_driver(&multicam_driver);

    return 0;
}


// linux module interface functions (called by linux kernel)
int euresys_driver_init(void)
{
    return mc_init_module();
}

void driver_exit(void)
{
    mc_cleanup_module();
}

int device_open(struct inode *pnode, struct file *pfile)
{
    return mc_device_open(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev), 
                           &(pfile->private_data));
}

int device_release(struct inode *pnode, struct file *pfile)
{
    return mc_device_release(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev),
                              &(pfile->private_data));
}

struct inode *GetInode(struct file *pfile)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
    return pfile->f_dentry->d_inode;
#else
    return pfile->f_path.dentry->d_inode;
#endif
}

ssize_t device_read(struct file *pfile, char *buffer, size_t size, loff_t *f_pos)
{
    struct inode *pnode;
    pnode = GetInode(pfile);
    if (!pnode)
        return -1;

    return mc_device_read(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev), buffer,
                           size, &(pfile->private_data));
}

ssize_t device_write(struct file *pfile, const char *buffer, size_t size, loff_t *f_pos)
{
    struct inode *pnode;
    pnode = GetInode(pfile);
    if (!pnode)
        return -1;

    return mc_device_write(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev), buffer,
                            size, &(pfile->private_data));
}

int device_ioctl(struct inode *pnode, struct file *pfile, unsigned int cmd, 
                    unsigned long arg)
{
	return mc_device_ioctl(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev), cmd,
                           (PVOID)arg,  &(pfile->private_data));
}

long device_compat_ioctl(struct file *pfile, unsigned int cmd, unsigned long arg)
{
    struct inode *pnode;
    pnode = GetInode(pfile);
    if (!pnode)
        return -1;

    return mc_device_ioctl(MAJOR(pnode->i_rdev), MINOR(pnode->i_rdev), cmd,
                           (PVOID)arg,  &(pfile->private_data));
}

unsigned int device_poll(struct file *pfile, struct poll_table_struct *poll_table)
{
    unsigned int mask = 0;
    OS_NOTIFICATION_EVENT *event = mc_device_poll(&(pfile->private_data));
    if (event == NULL) {
        return (POLLIN|POLLRDNORM|POLLOUT|POLLWRNORM);
    }
    poll_wait(pfile, (wait_queue_head_t *)&event->event, poll_table);
    if(event->bNotified == TRUE)
        mask = POLLIN | POLLRDNORM;
    return mask;
}

INT32 MC_API mc_printk(const char * fmt, ...)
{
    int ret, size;
    char pTexte[1024];
    va_list args;

    va_start(args, fmt);
    size = sprintf(pTexte, KERN_ERR "%s: ", driver_name);
    vsprintf(&pTexte[size], fmt, args);
    va_end(args);

    ret = printk(pTexte);

    return ret ;
}

// Register/unregister driver function: 
// the driver must be registered once to obtain a major number
// it must also be unregistered when unloaded!
INT32 MC_API mc_register_device(const char *name)
{
    INT32 major;

    major = register_chrdev(0, name, &fops);
    return major;
}

void MC_API mc_unregister_device(UINT32 major, const char *name)
{
    unregister_chrdev(major, name);
}

static int add_device(struct pci_dev *dev)
{
    MCDEVICEINFO McDev;
    int j;
    int ret;

    pci_enable_device(dev);

    McDev.ppcidev = (PVOID)dev;
    McDev.bus = dev->bus->number;
    McDev.slot = PCI_SLOT(dev->devfn);
    McDev.DeviceID = dev->device;
    McDev.VendorID = dev->vendor;
    McDev.SubDeviceID = dev->subsystem_device;
    McDev.SubVendorID = dev->subsystem_vendor;
    McDev.Irq = dev->irq;

    for (j = 0; j < DEVICE_COUNT_RESOURCE; j++)
    {
        if (dev->resource[j].flags & IORESOURCE_IO) {
            McDev.Resources[j].ResourceType = RESOURCE_IO;
        } else if (dev->resource[j].flags & IORESOURCE_MEM) {
            McDev.Resources[j].ResourceType = RESOURCE_MEM;
            McDev.Resources[j].u.mem.StartAddress = dev->resource[j].start;
            McDev.Resources[j].u.mem.Start.LowPart = dev->resource[j].start;
            McDev.Resources[j].u.mem.Size = dev->resource[j].end - dev->resource[j].start + 1;
        } else if (dev->resource[j].flags & IORESOURCE_IRQ) {
            McDev.Resources[j].ResourceType = RESOURCE_IRQ;
        } else if (dev->resource[j].flags & IORESOURCE_DMA) {
            McDev.Resources[j].ResourceType = RESOURCE_DMA;
        } else {
            McDev.Resources[j].ResourceType = RESOURCE_UNKNOWN;
        }
    }
    if (dev->irq != 0)
    {
        for (j = 0; j < DEVICE_COUNT_RESOURCE && McDev.Resources[j].ResourceType != RESOURCE_UNKNOWN; j++)
        {}
        if (j < DEVICE_COUNT_RESOURCE)
        {
            McDev.Resources[j].ResourceType = RESOURCE_IRQ;
            McDev.Resources[j].u.irq.vector = dev->irq;
        }
    }
    McDev.ResCount = DEVICE_COUNT_RESOURCE;

    ret = mc_add_device(&McDev);
    if (ret == 0)
        dev_number++;

    return ret;
}

// kernel memory allocation
/* Remark: the maximum size that can be allocated with kmalloc is 128K.
   For bigger sizes, use vmalloc.
*/
PVOID MC_API mc_kmalloc(size_t size, UINT32 pooltype)
{
    if (size > 0x20000)
    {
        mc_printk("mc_kmalloc: size (0x%x) too large\n", size);
        return NULL;
    }

    if (in_interrupt()) {
        return kmalloc(size, GFP_ATOMIC);
    } else {
        return kmalloc(size, GFP_KERNEL);
    }
}

void MC_API mc_kfree(PVOID ptr)
{
    kfree(ptr);
}

#ifndef EURESYS_OSAL_UNITTEST


PVOID MC_API mc_vmalloc(UINT32 size, UINT32 pooltype)
{
    if (in_interrupt())
    {
        mc_printk("mc_vmalloc: error: can't be used at interrupt time\n");
        return NULL;
    }
    return vmalloc(size);
}

void MC_API mc_vfree(PVOID ptr)
{
    vfree(ptr);
}


// map/unmap bus memory into CPU space
PVOID MC_API mc_ioremap_nocache (UINT32 offset, UINT32 size)
{
    return ioremap_nocache(offset, size);
}

void MC_API mc_iounmap(PVOID addr)
{
    iounmap(addr);
}

// readX/writeX() are used to access memory mapped devices
UINT32 MC_API mc_readl(PVOID address)
{
    return readl(address);
}

void MC_API mc_writel(UINT32 value, PVOID address)
{
    writel(value, address);
}

#endif

// ISR
// Set up and remove a hardware interrupt handler
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 19))
static irqreturn_t mc_isr(INT32 irq, PVOID context, struct pt_regs * regs)
#else
static irqreturn_t mc_isr(INT32 irq, PVOID context)
#endif
{
    BOOLEAN handled = FALSE;
    ISR_CTX *ctx = (ISR_CTX *)context;

    ISR_ROUTINE routine = (ISR_ROUTINE) ctx->Handler;

    handled = routine(irq, ctx->Context);

    return IRQ_RETVAL(handled);
}

#ifndef IRQF_SHARED
#define IRQF_SHARED SA_SHIRQ
#endif

INT32 MC_API mc_request_irq(OS_INTERRUPT *irq, MCIRQRESOURCES resources, PCCHAR dev_name, ISR_CTX *context)
{
    return request_irq(*irq, mc_isr, IRQF_SHARED, dev_name, context);
}

#ifndef EURESYS_OSAL_UNITTEST

void MC_API mc_free_irq(OS_INTERRUPT irq, PVOID context)
{
    free_irq(irq, context);
}



/*******************************/
/* Time management functions   */
/*******************************/
// Delay functions
void MC_API mc_udelay(UINT32 usecs)
{
    udelay(usecs);
}

void MC_API mc_mdelay(UINT32 msecs)
{
    mdelay(msecs);
}

/*******************************/
/* String management functions */
/*******************************/
INT32 MC_API mc_sprintf(PCHAR buf, PCCHAR fmt, ...)
{
    INT32 ret ;
    va_list args;

    va_start(args, fmt);
    ret = vsprintf (buf, fmt, args);

    va_end(args);
    return ret;
}

size_t MC_API mc_strlen(const char *s)
{
    return strlen (s);
}

#endif

/*******************************/
/* Memory management functions */
/*******************************/

UINT32 MC_API mc_GetPageCount(PVOID address, UINT32 buffer_size)
{
    ULONG page_offset;

    page_offset = ((ULONG)address) & PAGE_OFFSET_MASK;

    if (page_offset == 0) // The buffer is aligned on a page boundary
        return (buffer_size%PAGE_SIZE)? (buffer_size/PAGE_SIZE)+1 : buffer_size/PAGE_SIZE;
    else
        return ((page_offset+(buffer_size%PAGE_SIZE))>PAGE_SIZE)? (buffer_size/PAGE_SIZE)+2 : (buffer_size/PAGE_SIZE)+1;

}

#ifndef EURESYS_OSAL_UNITTEST

BOOLEAN MC_API mc_LockPages(PVOID address, UINT32 buffer_size)
{
    // nothing to do, pages are locked by the "get_user_pages" function.
    return TRUE;
}

void MC_API mc_UnlockPages(PVOID address, UINT32 buffer_size, _PAGE_ENTRY *page_list, UINT32 nents)
{
	UINT32 i;
	for (i = 0; i < nents; i++)
	{
		SetPageDirty((struct page *)page_list[i].PageObject);
		page_cache_release((struct page *)page_list[i].PageObject);
	}
}



/*******************/
/*  DMA functions  */
/*******************/

// Create an Adapter object (DMA handler)
PDMA_OBJECT MC_API mc_create_dma_object(PDEVICE phys_object, BOOLEAN dma64bit, UINT32 maxLength)
{
    //dma addresses are 32bit by default
    if (dma64bit){
        if (!pci_set_dma_mask((struct pci_dev *)phys_object, DMA_64BIT_MASK)){
            pci_set_consistent_dma_mask((struct pci_dev *)phys_object, DMA_32BIT_MASK);
        }
        else if (!pci_set_dma_mask((struct pci_dev *)phys_object, DMA_32BIT_MASK)){
            mc_printk("64bit dma not available! 32bit dma instead\n");
        }
        else{
            mc_printk("No suitable dma available\n");
            return NULL;
        }
    }
    return (PDMA_OBJECT)phys_object;
}

void MC_API mc_delete_dma_object(PDMA_OBJECT object)
{
    return;
}


// danger not valid for all memory
// return physical address from a virtual buffer address
PVOID MC_API mc_virtualtophysical(PVOID ptr)
{
    return ptr - PAGE_OFFSET;
}


PVOID MC_API mc_allocate_common_buffer(PHYSICAL_ADDR *physical_address,
                                       UINT32 size, PVOID adapter)
{
    dma_addr_t dmaAddress;
    PVOID virtual_address;

    virtual_address = pci_alloc_consistent(adapter,
                                           size,
                                           &dmaAddress);
    physical_address->QuadPart = dmaAddress;

    return virtual_address;
}

void MC_API mc_free_common_buffer(PVOID virtual_address,
                               PHYSICAL_ADDR physical_address,
                               UINT32 size,
                               PVOID adapter)
{
    if (virtual_address) {
        pci_free_consistent(adapter, size, virtual_address, (dma_addr_t) (physical_address.QuadPart));
    }
}



inline dma_addr_t map_dma(struct pci_dev* adapter, unsigned long addr, int size, _PAGE_ENTRY *page) 
{
    dma_addr_t dma_handle;
    int result;

    int offset = addr & PAGE_OFFSET_MASK;

    down_read(&current->mm->mmap_sem);
    result = get_user_pages(current, current->mm, addr, 1, 1, 0, (struct page **) &page->PageObject, NULL);
    up_read(&current->mm->mmap_sem);
    if (result <= 0) {
         return 0;
    }

    dma_handle = pci_map_page(adapter, (struct page *)page->PageObject, offset, size, PCI_DMA_FROMDEVICE);

    return dma_handle;
}


void MC_API mc_MapPciDma(PDMA_OBJECT adapter, PVOID CurrentVa, UINT32 remainingLength, PUINT32 length, _PAGE_ENTRY *page)
{
    dma_addr_t physaddr;

    if (CurrentVa == NULL) {
        page->Base.LowPart = 0;
        page->Base.HighPart = 0;
        return;
    }

    if (remainingLength<PAGE_SIZE) {
         *length = remainingLength;
    } else {
        if ( ((ULONG)CurrentVa) & PAGE_OFFSET_MASK) {
            *length = PAGE_SIZE - ( ((ULONG)CurrentVa) & PAGE_OFFSET_MASK);
        } else {
            *length = PAGE_SIZE;
        }
    }

    physaddr = map_dma(adapter, (ULONG)CurrentVa, *length, page);

    page->Base.QuadPart = physaddr;
    return;
}

UINT32 MC_API mc_CopyFromUser(PVOID to, const PVOID from, UINT32 n)
{
    return copy_from_user(to, from, n);
}


/***********************************/
/* /proc file management functions */
/***********************************/

static READ_PROC_ROUTINE ReadProcRoutine;

static int read_proc_entry(char *page, char **start, off_t off, int count, int *eof, void *data)
{
    return ReadProcRoutine(page, start, (PVOID)off, count, eof, data);
}

PVOID MC_API mc_create_proc_read_entry (const char *name, PVOID read_proc)
{
    ReadProcRoutine = (READ_PROC_ROUTINE) read_proc;
    return (PVOID) create_proc_read_entry(name,
                        S_IFREG | S_IRUGO | S_IWUSR,
                        0,
                        (read_proc_t *) read_proc_entry,
                        0);
}

void MC_API mc_remove_proc_entry (const char *name)
{
    remove_proc_entry(name, 0);
}

/*****************************************/
/* Scheduler task queue (system process) */
/*****************************************/

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
static void work_entry(void * work)
#else
static void work_entry(struct work_struct *work)
#endif
{
    WORK_CTX *ctx = container_of((OS_TASK *)work, WORK_CTX, task);
    WORK_ROUTINE routine = ctx->work;
    routine(ctx->context);
}

BOOLEAN MC_API mc_create_system_thread(WORK_CTX *data)
{
    struct work_struct *work = (struct work_struct *)&data->task;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
    INIT_WORK(work, work_entry, work);
#else
    INIT_WORK(work, work_entry);
#endif
    return schedule_work(work) != 0 ? TRUE : FALSE;
}

void MC_API mc_terminate_system_thread(void)
{
    return;
}

module_init(euresys_driver_init);
module_exit(driver_exit);

#endif


