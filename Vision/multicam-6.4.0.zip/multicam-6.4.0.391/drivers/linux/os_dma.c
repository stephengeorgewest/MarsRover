#include "mc_linux.h"

typedef struct _MEMORY_DESCRIPTION{
    void * virtualAddress;
    unsigned int length;
    unsigned int offset;
    unsigned int pageCount;
    struct page **pages;
    struct _MEMORY_DESCRIPTION *next;
} MEMORY_DESCRIPTION;

typedef struct{
    int numberOfElements;
    int totalPageCount;
    struct scatterlist *elements;
} SG_LIST;

#include "../os_dma.h"
#include "../mc_interface.h"

MEMORY_DESCRIPTION * MC_API OsCreateMemoryDescription(void *buffer,
                                                      unsigned int length)
{
    MEMORY_DESCRIPTION *memory;
    const unsigned long pageOffsetMask = PAGE_SIZE - 1;
    size_t size;
    
    size = mc_GetPageCount(buffer, length) * sizeof(void *);
    memory = (MEMORY_DESCRIPTION *)mc_kmalloc(sizeof(MEMORY_DESCRIPTION), 0);
    memory->virtualAddress = buffer;
    memory->length = length;
    memory->offset = (unsigned long)buffer & pageOffsetMask;
    memory->pages = (struct page **)mc_kmalloc(size, 0);
    memory->next = NULL;
    return memory;
}

void MC_API OsFreeMemoryDescription(MEMORY_DESCRIPTION *memory)
{
    mc_kfree(memory->pages);
    mc_kfree(memory);
}

BOOLEAN MC_API OsGetUserPages(MEMORY_DESCRIPTION *memory)
{
    int pageCount;
    int requestedPageCount = mc_GetPageCount(memory->virtualAddress, memory->length);

    down_read(&current->mm->mmap_sem);
    pageCount = get_user_pages(current, current->mm, 
                              (unsigned long)memory->virtualAddress, 
                               requestedPageCount, 1, 0, memory->pages, NULL);
    up_read(&current->mm->mmap_sem);
    if (pageCount < requestedPageCount) {
        int i;
        for (i = 0; i < pageCount; i++) {
            page_cache_release(memory->pages[i]);
        }
        return FALSE;
    }
    memory->pageCount = pageCount;
    return TRUE;
}

void MC_API OsPutUserPages(MEMORY_DESCRIPTION *memory)
{
    unsigned int i;
    for (i = 0; i < memory->pageCount; i++) {
        SetPageDirty(memory->pages[i]);
        page_cache_release(memory->pages[i]);
    }
}

void MC_API OsChainMemoryDescription(MEMORY_DESCRIPTION **memoryList, unsigned int size)
{
    unsigned int i;

    for (i = 0; i < size - 1; i++) {
        MEMORY_DESCRIPTION *memory = memoryList[i];
        while (memory->next)
            memory = memory->next;
        memory->next = memoryList[i + 1];
    }
}

unsigned int GetTotalPageCount(MEMORY_DESCRIPTION *memory)
{
    unsigned int totalPageCount = 0;

    while (memory != NULL) {
        totalPageCount += memory->pageCount;
        memory = memory->next;
    }
    return totalPageCount;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24))
static void sg_set_page(struct scatterlist *sg, struct page *page, unsigned int length, unsigned int offset)
{
    sg->page = page;
    sg->offset = offset;
    sg->length = length;
}
#endif

static void PopulateSglist(MEMORY_DESCRIPTION *memory, struct scatterlist *sglist)
{
    int i;
    int remainingLength;
    int sglistEntry = 0;

    while (memory != NULL) {
        remainingLength = memory->length;
        if (memory->pageCount > 1) {
            sg_set_page(&sglist[sglistEntry], memory->pages[0], PAGE_SIZE - memory->offset, memory->offset);
            remainingLength -= sglist[sglistEntry].length;
            sglistEntry++;
            for (i = 1; i < memory->pageCount; i++) {
                unsigned int length = PAGE_SIZE < remainingLength ? PAGE_SIZE : remainingLength;
                sg_set_page(&sglist[sglistEntry], memory->pages[i], length, 0);
                remainingLength -= length;
                sglistEntry++;
            }
        } else {
            sg_set_page(&sglist[sglistEntry], memory->pages[0], memory->length, memory->offset);
            sglistEntry++;
        }
        memory = memory->next;
    } 
}

int MC_API OsGetScatterGatherList(MEMORY_DESCRIPTION *memory,
                                      PDEVICE device, PDMA_OBJECT adapter,
                                      struct ScatterGatherCallbackContext *context)
{
    int result;
    SG_LIST *scatterGatherList;
    struct scatterlist *sglist;
    unsigned int totalPageCount;

    totalPageCount = GetTotalPageCount(memory);
    scatterGatherList = (SG_LIST *)mc_kmalloc(sizeof(SG_LIST), 0);
    sglist = (struct scatterlist *)mc_kmalloc(sizeof(struct scatterlist[totalPageCount]), 0);
    if (scatterGatherList == NULL || sglist == NULL) {
        mc_kfree(sglist);
        mc_kfree(scatterGatherList);
        return GET_SG_INSUFFICIENT_RESOURCES;
    }
    scatterGatherList->totalPageCount = totalPageCount;

    PopulateSglist(memory, sglist);
    result = pci_map_sg((struct pci_dev *)adapter, sglist, totalPageCount,
                        PCI_DMA_FROMDEVICE);
    if (result <= 0) {
        mc_kfree(sglist);
        mc_kfree(scatterGatherList);
        return GET_SG_FAILURE;
    }
    scatterGatherList->numberOfElements = result;
    scatterGatherList->elements = sglist;
    context->callback(scatterGatherList, context->context);
    return GET_SG_SUCCESS;
}

void MC_API OsPutScatterGatherList(SG_LIST **scatterGatherList,
                                   PDMA_OBJECT adapter)
{
    pci_unmap_sg((struct pci_dev *)adapter, (*scatterGatherList)->elements,
                 (*scatterGatherList)->totalPageCount, PCI_DMA_FROMDEVICE);
    mc_kfree((*scatterGatherList)->elements);
    mc_kfree(*scatterGatherList);
    *scatterGatherList = NULL;
}

unsigned int MC_API OsGetSgLength(SG_LIST *sgList, unsigned int element)
{
    if (element < sgList->numberOfElements) {
        return sg_dma_len(&(sgList->elements[element]));
    }
    return 0xFFFFFFFF;
}

PHYSICAL_ADDR MC_API OsGetSgPhysicalAddress(SG_LIST *sgList, unsigned int element)
{
    PHYSICAL_ADDR address;
    if (element < sgList->numberOfElements) {
        address.QuadPart = sg_dma_address(&(sgList->elements[element]));
        return address;
    }
    address.QuadPart = -1LL;
    return address;
}


