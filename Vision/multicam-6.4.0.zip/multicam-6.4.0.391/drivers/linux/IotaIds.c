#include "mc_linux.h"

const struct pci_device_id multicam_ids[] = {
	{PCI_DEVICE(0x1805,0x0401)},
	{0,0}
};

char *driver_name = "iota";

MODULE_DEVICE_TABLE(pci, multicam_ids);

