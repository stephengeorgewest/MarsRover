#include "mc_linux.h"
#include "../mc_interface.h"
#include "../os_synchro.h"

int MC_API OsSemaInit(OS_SEMA *lock, int initCount, int maxCount) 
{
    sema_init((struct semaphore *) lock, initCount);

    return OS_OK;
}

int MC_API OsSemaWait(OS_SEMA *lock) 
{
    int result;
    result=down_interruptible((struct semaphore*)lock);

    if(result<0) 
        return OS_WAIT_ALERTED;

    return OS_OK;
}

int MC_API OsSemaTimedWait(OS_SEMA *lock, int timeout) 
{
    return OsSemaWait(lock);
}

int MC_API OsSemaRelease(OS_SEMA *lock)
{
    up((struct semaphore*)lock);

    return OS_OK;
}

int MC_API OsSemaDelete(OS_SEMA *lock) 
{
    /* nothing to do*/
    return OS_OK;
}


int MC_API OsMutexInit(OS_MUTEX *lock) 
{
    return OsSemaInit((OS_SEMA*)lock,1,1);
}

int MC_API OsMutexWait(OS_MUTEX *lock) 
{
    return OsSemaWait((OS_SEMA*)lock);
}

int MC_API OsMutexRelease(OS_MUTEX *lock) 
{
    return OsSemaRelease((OS_SEMA*)lock);
}

int MC_API OsMutexDelete(OS_MUTEX *lock) 
{
    return OsSemaDelete((OS_SEMA*)lock);
}


int MC_API OsSpinLockInit(OS_SPINLOCK *spinlock) 
{
    spin_lock_init((spinlock_t *)spinlock);

    return OS_OK;
}

int MC_API OsSpinLockWait(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_lock_bh((spinlock_t *)spinlock);

    return OS_OK;
}

int MC_API OsSpinLockRelease(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_unlock_bh((spinlock_t *)spinlock);

    return OS_OK;
}

int MC_API OsSpinLockWaitDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    spin_lock((spinlock_t *)spinlock);

    return OS_OK;
}

int MC_API OsSpinLockReleaseDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_unlock((spinlock_t *)spinlock);

    return OS_OK;
}

int MC_API OsSpinLockWaitIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    unsigned long flags;

    spin_lock_irqsave((spinlock_t *)spinlock, flags);
    *context = flags;

    return OS_OK;
}

int MC_API OsSpinLockReleaseIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    unsigned long flags;

    flags = *context;
    spin_unlock_irqrestore((spinlock_t *)spinlock, flags);

    return OS_OK;
}

int MC_API OsSpinLockDelete(OS_SPINLOCK *spinlock)
{
    /*nothing to do*/
    return OS_OK;
}

int MC_API OsNotificationEventInit(OS_NOTIFICATION_EVENT *event)
{
    init_waitqueue_head((wait_queue_head_t*) &(event->event));
    event->bNotified=FALSE;
    return OS_OK;
}

int MC_API OsNotificationEventWait(OS_NOTIFICATION_EVENT *event)
{
    int result=OS_OK;
    wait_queue_head_t *pQueue;
    wait_queue_t wait;

    pQueue=(wait_queue_head_t*)&(event->event);
    init_waitqueue_entry(&wait,current);

    add_wait_queue(pQueue,&wait);
    while(1) {
        set_current_state(TASK_INTERRUPTIBLE);
        if (event->bNotified == TRUE) {
            result=OS_OK;
            break;
        }
        if(signal_pending(current)) {
            result=OS_WAIT_ALERTED;
            break;
	}
        schedule();
    }
    set_current_state(TASK_RUNNING);
    remove_wait_queue(pQueue,&wait);

    //translate result
    return result;
}

int MC_API OsNotificationEventWaitUninterruptible(OS_NOTIFICATION_EVENT *event)
{
    int result = OS_OK;
    wait_queue_head_t *pQueue;
    wait_queue_t wait;

    pQueue = (wait_queue_head_t *)&(event->event);
    init_waitqueue_entry(&wait, current);

    add_wait_queue(pQueue, &wait);
    while(1) {
        set_current_state(TASK_UNINTERRUPTIBLE);
        if (event->bNotified == TRUE) {
            result = OS_OK;
            break;
        }
        schedule();
    }
    set_current_state(TASK_RUNNING);
    remove_wait_queue(pQueue, &wait);

    return result;
}

int MC_API OsNotificationEventTimedWait(OS_NOTIFICATION_EVENT *event, int timeout)
{
    return OsNotificationEventWait(event);
}

int MC_API OsNotificationEventRelease(OS_NOTIFICATION_EVENT *event)
{
    event->bNotified=TRUE;
    wake_up((wait_queue_head_t*) &(event->event));

    return OS_OK;
}

int MC_API OsNotificationEventDelete(OS_NOTIFICATION_EVENT *event)
{
    return OS_OK;
}

int MC_API OsNotificationEventClear(OS_NOTIFICATION_EVENT *event)
{
    event->bNotified=FALSE;

    return OS_OK;
}

int MC_API OsSynchronizeIrqExecution(OS_SYNC_ROUTINE syncRoutine,
                                     PVOID syncRoutineContext,
                                     OS_INTERRUPT itr,
                                     OS_SYNC_ITR_LOCAL local)
{
    disable_irq(itr);
    syncRoutine(syncRoutineContext);
    enable_irq(itr);

    return OS_OK;
}

int MC_API OsSleep(unsigned int ms_delay) 
{
    unsigned long timeout = ((ms_delay * HZ + 999) / 1000) + 1;
    set_current_state(TASK_INTERRUPTIBLE);
    schedule_timeout(timeout);

    return OS_OK;
}

int MC_API OsStallProcessor(unsigned int usecs) 
{
    if(usecs>1500) {
        mdelay(usecs/1000);
        udelay(usecs%1000);
    } else {
        udelay(usecs);
    }

    return OS_OK;
}

/**
Return the number of processor ticks.
 **/
LONGLONG MC_API OsGetCpuTicks()
{
    return get_cycles();
}

/**
  Returns the number of processor ticks in KHz.

  Call it only in the context of a process.
**/
LONGLONG MC_API OsGetCpuTicksFrequency() 
{
    LONGLONG ticks;
    static LONGLONG frequency=0;
    struct timeval tv_start,tv_end;
    unsigned long time_delta, ih, il,tik;

    if (frequency!=0) {
        return frequency;
    }

    ticks = OsGetCpuTicks();
    do_gettimeofday(&tv_start);

    OsSleep(1020);

    do_gettimeofday(&tv_end);
    ticks = OsGetCpuTicks() - ticks;

    if(ticks==0) {
        return 1; // error
    }

    time_delta= (tv_end.tv_sec-tv_start.tv_sec)*1000000 + (tv_end.tv_usec-tv_start.tv_usec);

    tik=(ULONG)ticks;
    ih=((tik&0xFFFF0000)>>10)*1000/time_delta;
    il=((tik&0xFFFF)<<6)*1000/time_delta+(1<<5);

    /*mc_printk("OsGetCpuTicksFrequency ticks %d timedelta%d freq=%d\n",
                tik,time_delta, (ih<<10)| (il)>>6);*/

    frequency=(ih<<10)| (il)>>6;

    return frequency;
}

/**
  Returns the number of microseconds since Epoch (00:00:00 UTC, January 1, 1970).
**/
LONGLONG MC_API OsGetTimeSinceEpoch_us()
{
    LONGLONG time_us;
    struct timeval tv;
    do_gettimeofday(&tv);
    time_us = ((LONGLONG)tv.tv_sec*1000000) + tv.tv_usec;
    return time_us;
}

/**
  Returns the number of microseconds since Epoch (00:00:00 UTC, January 1, 1970).
**/
LONGLONG MC_API OsGetSystemTime_us()
{
    LONGLONG time_ms;
    struct timeval tv;
    do_gettimeofday(&tv);
    time_ms = ((LONGLONG)tv.tv_sec*1000000) + tv.tv_usec;
    return time_ms;
}

int MC_API OsTimerInit(OS_TIMER *Timer)
{
    init_timer((struct timer_list *)Timer);
    return OS_OK;
}

int MC_API OsTimerCancel(OS_TIMER *Timer)
{
    del_timer((struct timer_list *)Timer);
    return OS_OK;
}

static void timer_entry(unsigned long data)
{
    TIMER_CTX *ctx = (TIMER_CTX *) data;
    TIMER_HANDLER routine = (TIMER_HANDLER) ctx->task;
    routine(ctx->context);
}

BOOLEAN MC_API OsTimerSetOnce(OS_TIMER *aTimer, UINT32 DueTimeMs, TIMER_HANDLER Routine, PVOID arg1)
{
    struct timer_list *timer = (struct timer_list *)aTimer;
    ULONG expires = jiffies + (DueTimeMs*HZ)/1000;
    //timer->expires = expires;
    timer->data = (UINT_PTR)arg1;
    timer->function = timer_entry;
    mod_timer(timer, expires);
    //add_timer(timer);
    return OS_OK;
}
