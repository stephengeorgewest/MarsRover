#include "mc_linux.h"

const struct pci_device_id multicam_ids[] = {
	{PCI_DEVICE(0x10B5,0x2491)},
	{PCI_DEVICE(0x1805,0x0302)},
	{0,0}
};

char *driver_name = "glvalue";

MODULE_DEVICE_TABLE(pci, multicam_ids);

