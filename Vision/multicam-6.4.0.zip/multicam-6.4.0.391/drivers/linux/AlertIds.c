#include "mc_linux.h"

const struct pci_device_id multicam_ids[] = {
	{PCI_DEVICE(0x1805,0x0201)},
	{PCI_DEVICE(0x1805,0x0204)},
	{PCI_DEVICE(0x1805,0x0205)},
	{PCI_DEVICE(0x1805,0x0207)},
	{0,0}
};

char *driver_name = "alert";

MODULE_DEVICE_TABLE(pci, multicam_ids);

