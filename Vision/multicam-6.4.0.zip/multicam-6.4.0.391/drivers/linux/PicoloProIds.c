#include "mc_linux.h"

const struct pci_device_id multicam_ids[] = {
	{PCI_DEVICE(0x109E,0x036E)},
	{0,0}
};

char *driver_name = "picolopro";

MODULE_DEVICE_TABLE(pci, multicam_ids);
