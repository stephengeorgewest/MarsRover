/**
   \file os_synchro.h

   Portable synchronisation routines provided by the operating system.
   This is an interface to the functions implemented in lx_syncho.h and
   lx_synchro.c

   \author Francois Beerten
**/

#ifndef __OS_SYNCHRO_H
#define __OS_SYNCHRO_H

#define OS_OK 0
#define OS_ERROR 1
#define OS_WAIT_ALERTED 88
#define OS_WAIT_TIMEOUT 99
#define OS_WAIT_DEADLOCK 111
#define OS_OVERFLOW 222

#if defined(EURESYS_LINUX) && (!defined(EURESYS_UNITTEST) || defined EURESYS_OSAL_UNITTEST)
    #include "./linux/os_types.h"
    #include "./linux/os_synchro_types.h"
#elif defined EURESYS_WDM
    extern "C"
    {
        #include <wdm.h>
    }
    #include "./windows/os_synchro_types.h"
#endif


#ifdef __cplusplus
extern "C" 
{
#endif

  /** Initialize a semaphore

     \param lock Semaphore structure (type OS_SEMA)
     \param initCount Initial value of the semaphore
     \param maxCount ignored in Linux

     \sa OsSemaInit, OsSemaWait, OsSemaRelease, OsSemaDelete
  **/
  int MC_API OsSemaInit(OS_SEMA *lock, int initCount, int maxCount);

  /** Wait on a semaphore and decrement it

     Call allowed only in the context of a process.
     This is an interruptible wait.If the return value is OS_ALERTED, 
     the system call should abort and return -ESYSRESTART. The caller 
     should try again or completely abort the operation.

     The semaphore must have been initialized by OsSemaInit.

     \sa OsSemaInit, OsSemaWait, OsSemaRelease, OsSemaDelete 
  **/
  int MC_API OsSemaWait(OS_SEMA *lock);

  /** Wait during a limited time on a semaphore and decrement it.

     WARNING: On Linux the timeout is ignored !

     Call allowed only in the context of a process.

     The semaphore must have been initialized by OsSemaInit.

     \param timeout Timeout for the wait expressed in milliseconds
     \sa OsSemaInit, OsSemaWait, OsSemaRelease, OsSemaDelete 
  **/
  int MC_API OsSemaTimedWait(OS_SEMA *lock, int timeout);

  /** Release a semaphore incrementing it and wake threads waiting on it.

     The semaphore must have been initialized by OsSemaInit.

     \sa OsSemaInit, OsSemaWait, OsSemaRelease, OsSemaDelete
  **/
  int MC_API OsSemaRelease(OS_SEMA *lock);

  /** Free a semaphore

     No more threads may be waiting on the semaphore or
     you're gonna have a lot of trouble.

     The semaphore must have been initialized by OsSemaInit.
     Windows limitation: Callers of KeReleaseSemaphore must be running
     at IRQL <= DISPATCH_LEVEL.

     \sa OsSemaInit, OsSemaWait, OsSemaRelease, OsSemaDelete
   **/
  int MC_API OsSemaDelete(OS_SEMA *lock);


  /** Initialize a mutex, also called critical section

     A mutex must be initialized before any other operation on it.
  **/
  int MC_API OsMutexInit(OS_MUTEX *lock);

  /** Enter into a mutex, also called critical section

     The mutex must have been initialized with OsMutexInit. Call
     OsMutexWait only once when entering a mutex. Dont call
     OsMutexWait again while already in the mutex.

     Call allowed only int he context of a process.
     This is an interruptible wait.If the return value is OS_ALERTED, 
     the system call should abort and return -ESYSRESTART. The caller 
     should try again or completely abort the operation.

     \sa OsMutexInit, OsMutexWait, OsMutexRelease, OsMutexDelete
  **/
  int MC_API OsMutexWait(OS_MUTEX *lock);

  /** Leave a mutex, also called critical section

     The mutex must have been initialized with OsMutexInit 
     and taken with OsMutexWait. Call osMutexRelease only once
     when leaving a mutex. Windows limitation: Callers of 
     KeReleaseSemaphore must be running at IRQL <= DISPATCH_LEVEL.

     \sa OsMutexInit, OsMutexWait, OsMutexRelease, OsMutexDelete
  **/
  int MC_API OsMutexRelease(OS_MUTEX *lock);

  /** Free an initialized mutex

     The mutex must have been initialized with OsMutexInit and nobody may be waiting
     on it anymore.
     \sa OsMutexInit, OsMutexWait, OsMutexRelease, OsMutexDelete
  **/
  int MC_API OsMutexDelete(OS_MUTEX *lock);

  /** Initialize a spinlock

     For mutual exclusion with high priority routines like interrupt handlers,
     DPC's, or tasklets.
     The spinlock must have been initialized with OsSpinLockInit

     This function should only be called in the context of a process.
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
  **/
  int MC_API OsSpinLockInit(OS_SPINLOCK *spinlock);

  /** Spin on a lock and acquire it

     For mutual exclusion with high priority routines like interrupt handlers
     or DPC's, or tasklets.

     This function can be called in the context of a process or at DPC level.
     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
  **/
  int MC_API OsSpinLockWait(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);


  /** Release a spinlock

     For mutual exclusion with high priority routines like interrupt handlers
     or DPC's, or tasklets.

     This function can be called in the context of a process or at DPC level.
     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
  **/
  int MC_API OsSpinLockRelease(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);

  /** Spin on a lock and acquire it

     For mutual exclusion with high priority routines like interrupt handlers
     or DPC's, or tasklets.

     This function should only be called in high priority routines 
     like interrupt handlers, DPC's, or tasklets. .
     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
     \sa OsSpinLockWaitDpc, OsSpinLockReleaseDpc
  **/
  int MC_API OsSpinLockWaitDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);

  /** Release a spinlock

     For mutual exclusion with high priority routines like interrupt handlers,
     DPC's, or tasklets.

     This function should only be called in high priority routines 
     like interrupt handlers or DPC's, or tasklets.
     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
     \sa OsSpinLockWaitDpc, OsSpinLockReleaseDpc
  **/
  int MC_API OsSpinLockReleaseDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);

  /** Acquire a spinlock

     For mutual exclusion with interrupt handlers.

     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
     \sa OsSpinLockWaitDpc, OsSpinLockReleaseDpc
  **/
  int MC_API OsSpinLockWaitIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);

  /** Release a spinlock

     For mutual exclusion with interrupt handlers.

     The spinlock must have been initialized with OsSpinLockInit
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
     \sa OsSpinLockWaitDpc, OsSpinLockReleaseDpc
  **/
  int MC_API OsSpinLockReleaseIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context);

  /** Free a spinlock

     This function should only be called in context of a process.
     The spinlock must have been initialized with OsSpinLockInit and nobody
     may be waiting on it anymore.
     \sa OsSpinLockInit, OsSpinLockWait, OsSpinLockRelease, OsSpinLockDelete
     \sa OsSpinLockWaitDpc, OsSpinLockReleaseDpc
  **/
  int MC_API OsSpinLockDelete(OS_SPINLOCK *spinlock);


  /** Initialize a notification event

     An notification event is a special synchronisation event 
     which signals something to all its waiting threads. On a OsNotificationEventRelease,
     all waiting threads are woken up untill the event is cleared with 
     OsNotificationEventClear.

     Must be called before any other OsNotificationEvent* function.
     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventClear
  **/
  int MC_API OsNotificationEventInit(OS_NOTIFICATION_EVENT *event);

  /** Wait on a notification event.

     Allowed only in the context of a process.
     Warning, other waiting threads will also wake up! 

     Alertable WITHOUT notice ! Caller should check its own status data
     to be sure the wait didn't abort.

     The event must have been initialized with OsEventInit before using it.

     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventInit, OsNotificationEventClear
  **/
  int MC_API OsNotificationEventWait(OS_NOTIFICATION_EVENT *event);

  /** Wait on a notification event in a uninterruptible way.

      Allowed only in the context of a process.
      Warning, other waiting threads will also wake up!

      No signal can interrupt the wait so make sure the condition will be
      satisfied and that it won't wait too long.

      The event must have been initialized with OsEventInit before using it.

      \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
      \sa OsNotificationEventInit, OsNotificationEventClear
  **/
    int MC_API OsNotificationEventWaitUninterruptible(OS_NOTIFICATION_EVENT *event);

  /** Wait on a notification event during a limited time.

     Allowed only in the context of a process.
     Warning, other waiting threads will also wake up! 

     WARNING: On Linux the timeout is ignored !

     The event must have been initialized with OsEventInit before using it.

     \param timeout Timeout for the wait expressed in milliseconds
     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventInit, OsNotificationEventClear
  **/
  int MC_API OsNotificationEventTimedWait(OS_NOTIFICATION_EVENT *event, int timeout);

  /** Release an event waking all threads sleeping on it.

     The event must have been initialized with OsEventInit before using it.

     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventInit, OsNotificationEventClear
  **/
  int MC_API OsNotificationEventRelease(OS_NOTIFICATION_EVENT *event);

  /** Resets the notification event.

     When a notification event is cleared, any OsNotificationWait will
     wait till a new OsNotificationEventRelease.

     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventInit
  **/
  int MC_API OsNotificationEventClear(OS_NOTIFICATION_EVENT *event);

  /** Free an initialized event

     No more threads may be waiting on the event when deleting it.

     \sa OsNotificationEventWait, OsNotificationEventRelease, OsNotificationEventDelete
     \sa OsNotificationEventInit
  **/
  int MC_API OsNotificationEventDelete(OS_NOTIFICATION_EVENT *event);



  typedef BOOLEAN MC_API (*OS_SYNC_ROUTINE)(PVOID);

  /** Synchronize the execution of the function with the given interrupt.

     \param syncRoutine The callback fucntion called when synchronized. 
                        Should be fast. 
                        The callback has the prototype: 
                          BOOLEAN syncRoutine(PVOID syncRoutineContext).
     \param syncRoutineContext Argument passed to the callback function
     \param itr Interrupt to synchronize with
     \param local OS_SYNC_ITR_LOCAL variable declared on the stack for internal use
  **/
  int MC_API OsSynchronizeIrqExecution(OS_SYNC_ROUTINE syncRoutine, 
                                       PVOID syncRoutineContext,
                                       OS_INTERRUPT itr,
                                       OS_SYNC_ITR_LOCAL local);

  /** Put the process to sleep for a given period

     This function can only be called in the context of a process 
     or big trouble will happen.

     \param ms_delay The time in ms to sleep.
  **/
  int MC_API OsSleep(unsigned int ms_delay);

  /** Sleep with a busy loop

     For small (<<1ms) and precise sleeps call OsStallProcessor. 
     This is a busy wait, stalling the CPU and the whole system. 
     Use with care and avoid it when posible.
  **/
  int MC_API OsStallProcessor(unsigned int usecs);

  /** Returns the number of processor ticks. **/
  LONGLONG MC_API OsGetCpuTicks();

  /** Returns the number of processor ticks. **/
  LONGLONG MC_API OsGetCpuTicksFrequency();

  /** Returns the number of microseconds since Epoch.

     The Epoch is at 00:00:00 UTC, January 1, 1970.
  **/
  LONGLONG MC_API OsGetTimeSinceEpoch_us();

  /** Returns the number of microseconds since Epoch.

     The Epoch is at 00:00:00 UTC, January 1, 1970.
  **/
  LONGLONG MC_API OsGetSystemTime_us();

  int MC_API OsTimerInit(OS_TIMER *Timer);
  int MC_API OsTimerCancel(OS_TIMER *Timer);
  BOOLEAN MC_API OsTimerSetOnce(OS_TIMER *Timer, UINT32 DueTimeMs,
                                TIMER_HANDLER Routine, PVOID arg1);


#ifdef __cplusplus
}
#endif


#endif
