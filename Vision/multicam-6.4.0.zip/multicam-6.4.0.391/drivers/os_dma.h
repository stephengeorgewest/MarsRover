#ifndef DMA_INTERFACE_HEADER
#define DMA_INTERFACE_HEADER

#include "os_size_t.h"
#include "os_dma_types.h"

#define GET_SG_SUCCESS 0
#define GET_SG_FAILURE -1
#define GET_SG_INSUFFICIENT_RESOURCES -2

typedef void MC_API (*ScatterGatherCallback)(SG_LIST *scatterGather, void *context);

struct ScatterGatherCallbackContext{
    ScatterGatherCallback callback;
    void *context;
};

#ifdef __cplusplus
extern "C" 
{
#endif
/** Allocates a structure large enough to describe buffer and initializes it.
**/
MEMORY_DESCRIPTION * MC_API OsCreateMemoryDescription(void *buffer,
                                                      unsigned int length);

/** Frees the structure memory that was allocated by OsCreateMemoryDescription.
**/
void MC_API OsFreeMemoryDescription(MEMORY_DESCRIPTION *memory);

/** Locks the buffer in memory and lists its physical pages.
**/
BOOLEAN MC_API OsGetUserPages(MEMORY_DESCRIPTION *memory);

/** Unlocks the pages described by memory
**/
void MC_API OsPutUserPages(MEMORY_DESCRIPTION *memory);

/** Chains the MEMORY_DESCRIPTIONs of the given list together, in the order.
 *  It modifies the MEMORY_DESCRIPTIONs to chain them.
**/
void MC_API OsChainMemoryDescription(MEMORY_DESCRIPTION **memoryList, unsigned int size);

/** Maps the pages described by memory for DMA and lists them in scatterGatherList.
 *  Allocates the scatterGatherList and passes it to the callback.
**/
int MC_API OsGetScatterGatherList(MEMORY_DESCRIPTION *memory,
                                      PDEVICE device, PDMA_OBJECT adapter,
                                      struct ScatterGatherCallbackContext *context);

/** Unmap the pages mapped by OsGetScatterGatherList and frees the 
 *  scatterGatherList structure allocated by OsGetScatterGatherList.
**/
void MC_API OsPutScatterGatherList(SG_LIST **scatterGatherList,
                                   PDMA_OBJECT adapter);

/** Returns the length of the element of the sgList. If element is out of the
 *  list, returns 0xFFFFFFFF;
**/
unsigned int MC_API OsGetSgLength(SG_LIST *sgList, unsigned int element);

/** returns the physical address of the element of the sgList. If element is 
 *  out of the list, returns a physical address -1LL;
**/
PHYSICAL_ADDR MC_API OsGetSgPhysicalAddress(SG_LIST *sgList, unsigned int element);
#ifdef __cplusplus
}
#endif

#endif


