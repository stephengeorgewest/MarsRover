#ifndef OS_SIZE_T
#define OS_SIZE_T

#if defined(EURESYS_UNITTEST)
    #include <stdlib.h>
#elif defined(EURESYS_WDM)
    #include <crtdefs.h>
#elif defined(EURESYS_LINUX)
    #ifndef _SIZE_T
    #define _SIZE_T
    #ifdef EURESYS_64_BITS
        typedef unsigned long size_t;
    #else
        typedef unsigned int size_t;
    #endif
    #endif
#endif

#endif
