#if defined(EURESYS_UNITTEST) && !defined(EURESYS_OSAL_UNITTEST)
#include "UnitTests/os_dma_types.h"
#elif defined(EURESYS_LINUX)
#include "./linux/os_dma_types.h"
#elif defined(EURESYS_WDM)
#include "./windows/os_dma_types.h"
#endif

