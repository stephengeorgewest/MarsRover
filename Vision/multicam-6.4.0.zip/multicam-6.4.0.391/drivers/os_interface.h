#ifndef __OS_INTERFACE_H__
#define __OS_INTERFACE_H__

#include "os_types.h" 

#ifdef __cplusplus
extern "C"
{
#endif
    
    INT32 MC_API mc_pci_read_config_byte(PDEVICE pcidev, UINT32 where, PUCHAR ptr);
    INT32 MC_API mc_pci_write_config_byte(PDEVICE pcidev, UINT32 where, UCHAR val);
    INT32 MC_API mc_pci_read_config_word(PDEVICE pcidev, UINT32 where, PUSHORT ptr);
    INT32 MC_API mc_pci_write_config_word(PDEVICE pcidev, UINT32 where, USHORT val);
    INT32 MC_API mc_pci_read_config_dword(PDEVICE pcidev, UINT32 where, PUINT32 ptr);
    INT32 MC_API mc_pci_write_config_dword(PDEVICE pcidev, UINT32 where, UINT32 val);
    
    void *MC_API os_memset(void *s, INT32 c, UINT32 n);
    void *MC_API os_memcpy(void *dest, const void *src, UINT32 n);
    void *MC_API os_memmove(void *dest, const void *src, UINT32 n);
  
    /** Create a barrier at this position in the code.
    **/
    void MC_API OsMemoryBarrier();

    
    struct OS_DPC {
        MC_API void (*callback)(PVOID context);
        PVOID context;
        // Sufficiently large to hold the os nativestructures used for dpc/tasklet objects
        unsigned char native_dpc[16*8]; 
    };

    /** Create a DPC.

        This function can be called only at the passive level.
        \param dpc pointer to a preallocated structure that will contain the dpc object
        \param callback        callback that will be called when executing the deferred
        \param context  context that will be passed to the callback
     **/
    void MC_API OsCreateDpc(struct OS_DPC *dpc, void (*callback)(PVOID context), PVOID context);

    /** Free a DPC.

        This function can be called only at the passive level. 
        No DPC may be running anymore.
        \param dpc pointer to the DPC object that needs to be freeed.
     **/
    void MC_API OsDeleteDpc(struct OS_DPC *dpc);

    /** Queue a call. The DPC will be run as soon as possible by the OS.

        This function can only be called when executing a deferred or an interrupt handler.
        \param dpc pointer to the DPC object.
     **/
    BOOLEAN MC_API OsQueueDpc(struct OS_DPC *dpc);

#ifdef __cplusplus
}
#endif

#endif

