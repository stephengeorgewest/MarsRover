#ifndef _MC_INTERFACE_H
#define _MC_INTERFACE_H

#include "os_size_t.h"
#include "os_types.h"
#include "os_synchro.h"

// ****************************************************************************
// MEMORY POOL TAG
#define EURESYS_POOL_TAG	'  CM' // -> 'MC  '

//Structures
typedef struct t_MemResources
{
	PHYSICAL_ADDR Start; // QWORD
	UINT32 StartAddress; // Start.LowPart
	UINT32 Size;
} MCMEMRESOURCES;

typedef struct t_IrqResources
{
	UINT32	vector;
	UCHAR	irq_level;
	UINT_PTR	affinity;
} MCIRQRESOURCES;

typedef struct t_DevResources
{
	UINT32 ResourceType;
	union
	{
		MCMEMRESOURCES	mem;
		MCIRQRESOURCES	irq;
	} u;
} MCDEVRESOURCES;

typedef struct t_DeviceInfo
{
	PDEVICE			ppcidev;
	UINT32			bus;
	UINT32			slot;
	USHORT			DeviceID;
	USHORT			VendorID;
 	USHORT			SubDeviceID;
	USHORT			SubVendorID;
	MCDEVRESOURCES	Resources[MC_MAX_RESOURCES];
	UINT32			ResCount;
	OS_INTERRUPT	Irq;
} MCDEVICEINFO, *PMCDEVICEINFO;

typedef struct {
  PVOID Handler;
  PVOID Context;
} ISR_CTX;

typedef struct {
  PVOID task;
  PVOID context;
} TASK_CTX;

typedef struct {
  OS_TASK task;
  WORK_ROUTINE work;
  PVOID context;
} WORK_CTX;

typedef struct {
  PVOID task;
  PVOID context;
} TIMER_CTX;

#ifdef __cplusplus
extern "C"
{
#endif
INT32 MC_API mc_init_module(void);
INT32 MC_API mc_register_driver(void);
INT32 MC_API mc_unregister_driver(void);
INT32 MC_API mc_add_device(PMCDEVICEINFO dev);
VOID MC_API mc_cleanup_module(void);

INT32 MC_API mc_device_open(INT32 Major, INT32 Minor, void **private_data);
INT32 MC_API mc_device_release(INT32 Major, INT32 Minor, void **private_data);
INT32 MC_API mc_device_read(INT32 Major, INT32 Minor, PCHAR buffer, UINT32 size,
                             void **private_data);
INT32 MC_API mc_device_write(INT32 Major, INT32 Minor, PCCHAR buffer, UINT32 size,
                             void **private_data);
INT32 MC_API mc_device_ioctl(INT32 Major, INT32 Minor, INT32 cmd, PVOID arg,
                             void **private_data);
OS_NOTIFICATION_EVENT *MC_API mc_device_poll(void **private_data);

PVOID MC_API mc_kmalloc(size_t size, UINT32 pooltype);
VOID  MC_API mc_kfree(PVOID ptr);

PVOID MC_API mc_vmalloc(UINT32 size, UINT32 pooltype);
VOID  MC_API mc_vfree(PVOID ptr);


INT32 MC_API mc_printk(PCCHAR fmt, ...);
INT32 MC_API mc_register_device(PCCHAR name);
void MC_API mc_unregister_device(UINT32 major, PCCHAR name);
INT32 MC_API mc_device_detection (UINT32 VendorID, UINT32 DeviceID,
                                  PMCDEVICEINFO Dev);
PVOID MC_API mc_ioremap_nocache(UINT32 offset, UINT32 size);
VOID  MC_API mc_iounmap(PVOID addr);
UINT32 MC_API mc_readl(PVOID address);
VOID  MC_API mc_writel(UINT32 value, PVOID address);

INT32 MC_API mc_request_irq(OS_INTERRUPT *irq, MCIRQRESOURCES resources,
                            PCCHAR dev_name, ISR_CTX *context);
VOID MC_API mc_free_irq(OS_INTERRUPT irq, PVOID context);

/*******************************/
/* Time management functions   */
/*******************************/
VOID MC_API mc_udelay(UINT32 usecs);
VOID MC_API mc_mdelay(UINT32 msecs);

/*******************************/
/* String management functions */
/*******************************/
INT32 MC_API mc_sprintf(PCHAR buf, PCCHAR fmt, ...);
size_t MC_API mc_strlen(const char *s);

/*******************************/
/* Memory management functions */
/*******************************/
UINT32 MC_API mc_GetPageCount(PVOID address, UINT32 size);
BOOLEAN MC_API mc_LockPages(PVOID address, UINT32 buffer_size);

PDMA_OBJECT MC_API mc_create_dma_object(PDEVICE phys_object, BOOLEAN dma64bit, UINT32 maxLength);
VOID MC_API mc_delete_dma_object(PDMA_OBJECT object);
PVOID MC_API mc_allocate_common_buffer(PHYSICAL_ADDR *physical_address, 
                                       UINT32 size, PVOID adapter);
VOID MC_API mc_free_common_buffer(PVOID virtual_address,
                                  PHYSICAL_ADDR physical_address,
                                  UINT32 size,
                                  PVOID adapter);
VOID MC_API mc_UnlockPages(PVOID address, UINT32 buffer_size,
                             _PAGE_ENTRY *page_list, UINT32 nents);
VOID MC_API mc_MapPciDma(PDMA_OBJECT adapter,
                         PVOID CurrentVa,
                         UINT32 remainingLength,
                         PUINT32 length,
                         _PAGE_ENTRY *page);
UINT32 MC_API mc_CopyFromUser(PVOID to, const PVOID from, UINT32 n);

/*****************************************/
/* Scheduler task queue (system process) */
/*****************************************/
    BOOLEAN MC_API mc_create_system_thread(WORK_CTX *data);
VOID MC_API mc_terminate_system_thread(void);

/***********************************/
/* /proc file management functions */
/***********************************/

PVOID MC_API mc_create_proc_read_entry(const char *name, PVOID read_proc);
VOID MC_API mc_remove_proc_entry(const char *name);

#ifdef __cplusplus
}
#endif

#endif

