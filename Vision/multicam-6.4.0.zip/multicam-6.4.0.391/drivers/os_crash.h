#ifndef OS_CRASH_HEADER_FILE
#define OS_CRASH_HEADER_FILE

#include "os_types.h"

#ifdef __cplusplus
extern "C" 
{
#endif
/** Produce a crash (blue screen on Windows, Oops on Linux) displaying the
    error code. 
 **/
void MC_API OsCrash(unsigned short errorCode);
#ifdef __cplusplus
}
#endif

#endif
